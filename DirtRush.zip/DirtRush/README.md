# Dirt Rush – Moto & Quad Freestyle

Gioco Android 2D (Kotlin, nessuna libreria esterna) ispirato al genere di Extreme Moto:
guida in orizzontale su terreni con colline e salti, acrobazie, monete e garage.
Tutta la grafica è disegnata a codice (Canvas): nessun asset da importare.

## Come aprirlo e installarlo
1. Installa **Android Studio** (versione recente) e scegli *Open* sulla cartella `DirtRush`.
2. Attendi la sincronizzazione Gradle (scarica da solo SDK 34 e dipendenze).
3. Collega il telefono con il debug USB attivo (o usa un emulatore) e premi **Run**.
4. Per un APK da condividere: *Build > Build Bundle(s) / APK(s) > Build APK(s)*.

Requisiti: Android 7.0 (API 24) o superiore.

## Comandi di gioco (orizzontale)
- **GAS / FRENO** (in basso a destra): accelera, frena e, da fermo, retromarcia.
- **MUSO SU / MUSO GIÙ** (in basso a sinistra): inclina il pilota; a terra per impennare, in aria per ruotare e fare flip.
- Atterra sulle ruote: ogni giro completo vale **+25 monete**.
- A fine corsa ottieni le monete raccolte più 1 ogni 20 m.

## Contenuto
**10 veicoli** (nomi di fantasia, con statistiche di potenza, aderenza, equilibrio, sospensioni e peso):
- Moto: Falco MX 250 (sbloccata), Falco MX 450, Tundra Enduro 300, Gnomo Trial 125, Vortex Supermoto, Thunder X-Pro
- Quad: Scarab Quad 200, Scarab Sport 450, Rhino Race 700, Yeti Monster 4x4

**4 mondi**: Deserto Dorato, Foresta Verde, Montagne Innevate, Notte Neon (con faro).

## Migliorie grafiche
- Cielo a gradiente, sole con alone, stelle e nuvole animate
- Montagne su 3 livelli con parallasse
- Terreno a strati con bordo erboso/sabbioso e ombre
- Moto e quad con ruote tassellate rotanti, forcella, ammortizzatori e pilota
- Particelle di polvere e scintille, ombra del veicolo, screen shake agli atterraggi
- Zoom dinamico e linee di velocità, vignettatura, HUD in stile vetro

## Struttura del codice (`app/src/main/java/com/dirtrush/game`)
| File | Contenuto |
|---|---|
| `Vehicles.kt` | Catalogo dei veicoli: aggiungine uno copiando una riga di `Catalog.vehicles` |
| `Themes.kt` | Mondi (colori, difficoltà) e disegno di sfondo/terreno |
| `Terrain.kt` | Terreno procedurale, rampe e monete |
| `Bike.kt` | Fisica del veicolo (corpo rigido, sospensioni, trazione) |
| `VehicleRenderer.kt` | Disegno di moto, quad e pilota |
| `Game.kt` | Logica di corsa, punteggio, salvataggi |
| `GameView.kt`, `Screens.kt`, `Ui.kt` | Loop di gioco, input multi-touch, menu e HUD |

## Note
Il progetto non è stato compilato su un dispositivo in questa sessione (l'ambiente non ha l'Android SDK):
la fisica è stata verificata con una simulazione a parte, ma la prima compilazione in Android Studio
potrebbe richiedere piccoli aggiustamenti. Il gioco non usa grafica, nomi o marchi di Extreme Moto.
