package com.dirtrush.game

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

/** Corpo rigido 2D del veicolo con due ruote a molla sul terreno. */
class Bike(val v: Vehicle, private val terrain: Terrain) {

    companion object {
        const val G = 9.81f
        const val AXLE_DROP = 0.35f      // distanza ruote sotto il baricentro
        const val HEAD_X = -0.05f
        const val HEAD_Y = 0.95f
        private const val TWO_PI = 6.2831855f
    }

    var x = 0f; var y = 0f
    var vx = 0f; var vy = 0f
    var angle = 0f; var omega = 0f

    var crashed = false
    var rearPen = 0f; var frontPen = 0f          // compressione sospensioni (m)
    var rearContact = false; var frontContact = false
    var rearSpin = 0f; var frontSpin = 0f        // angolo ruote per il disegno
    var airTime = 0f
    var lastFlips = 0                            // flip appena completati all'atterraggio
    var landedImpact = 0f                        // intensita' dell'ultimo atterraggio
    var landed = false                           // evento: appena atterrato

    private var airRot = 0f
    private val n = FloatArray(2)

    // Parametri derivati
    private val m = v.mass
    private val inertia = m * 0.5f
    private val half = v.wheelbase / 2f
    private val k = m * G * 0.5f / (0.10f * v.suspension)
    private val c = 2f * 0.38f * sqrt(k * m * 0.5f)
    private val driveFront = v.type == VehicleType.QUAD && v.style == Style.QUAD_UTILITY

    init { reset() }

    fun reset() {
        x = 0f
        y = terrain.height(0f) + v.wheelRadius + AXLE_DROP + 0.05f
        vx = 0f; vy = 0f; angle = 0f; omega = 0f
        crashed = false; airTime = 0f; airRot = 0f
    }

    fun headX() = x + HEAD_X * cos(angle) - HEAD_Y * sin(angle)
    fun headY() = y + HEAD_X * sin(angle) + HEAD_Y * cos(angle)

    /** Un sotto-passo di fisica. lean: +1 inclina indietro (muso su), -1 avanti. */
    fun step(dt: Float, gas: Float, brake: Float, lean: Float) {
        if (crashed) { stepCrashed(dt); return }
        val ca = cos(angle); val sa = sin(angle)
        var fx = 0f
        var fy = -m * G
        var torque = 0f
        var contacts = 0
        landed = false

        for (i in 0..1) {
            val bx = if (i == 0) -half else half
            val rx = bx * ca + AXLE_DROP * sa
            val ry = bx * sa - AXLE_DROP * ca
            val wx = x + rx
            val wy = y + ry
            val pen = terrain.height(wx) + v.wheelRadius - wy
            val onGround = pen > 0f
            if (i == 0) { rearContact = onGround; rearPen = max(0f, pen) }
            else { frontContact = onGround; frontPen = max(0f, pen) }
            if (!onGround) continue
            contacts++

            terrain.normal(wx, n)
            val nx = n[0]; val ny = n[1]
            val tx = ny; val ty = -nx
            val vwx = vx - omega * ry
            val vwy = vy + omega * rx
            val vn = vwx * nx + vwy * ny
            val vt = vwx * tx + vwy * ty

            var fn = k * pen - c * vn
            if (pen > 0.22f) fn += k * 6f * (pen - 0.22f)       // fine corsa
            fn = fn.coerceIn(0f, m * G * 14f)

            // Trazione / freno
            var ft = 0f
            val driven = (i == 0) || driveFront || v.type == VehicleType.QUAD
            if (driven && gas > 0f) {
                val share = if (v.type == VehicleType.QUAD || driveFront) 0.5f else 1f
                ft += gas * v.power * m * share
            }
            if (brake > 0f) {
                if (vt > 0.8f) ft -= brake * m * 9f * 0.5f
                else if (i == 0) ft -= brake * v.power * m * 0.4f      // retromarcia dolce
            }
            ft -= vt * m * 0.06f                                      // resistenza al rotolamento
            val maxFt = v.grip * fn * 1.1f
            ft = ft.coerceIn(-maxFt, maxFt)

            val fX = fn * nx + ft * tx
            val fY = fn * ny + ft * ty
            fx += fX; fy += fY
            torque += rx * fY - ry * fX
        }

        // Resistenza dell'aria
        fx -= vx * abs(vx) * m * 0.0035f
        fy -= vy * abs(vy) * m * 0.0035f

        // Peso del pilota: inclinazione a terra e in aria
        val leanTorque = if (contacts == 0) 9f else 3.2f
        torque += lean * v.stability * inertia * leanTorque
        if (contacts == 0) {
            torque -= omega * inertia * 0.55f
        } else {
            // Assetto automatico a terra: il pilota tende ad allinearsi al terreno,
            // ma l'inclinazione volontaria (impennata) puo' ancora prevalere.
            val target = atan(terrain.slope(x))
            var d = angle - target
            while (d > PI.toFloat()) d -= TWO_PI
            while (d < -PI.toFloat()) d += TWO_PI
            torque += -d * inertia * 5f - omega * inertia * 1.3f
        }

        // Un po' di coppia di reazione quando si da' gas in aria (effetto "ruota che gira")
        if (contacts == 0) torque -= gas * inertia * 0.8f

        // Integrazione
        vx += fx / m * dt
        vy += fy / m * dt
        x += vx * dt
        y += vy * dt
        omega += torque / inertia * dt
        omega = omega.coerceIn(-12f, 12f)
        val dA = omega * dt
        angle += dA

        // Salti e flip
        if (contacts == 0) {
            airTime += dt
            airRot += dA
        } else {
            if (airTime > 0.25f) {
                lastFlips = (abs(airRot) / TWO_PI + 0.18f).toInt()
                landedImpact = min(1f, abs(vy) / 12f)
                landed = true
            }
            airTime = 0f; airRot = 0f
        }

        // Rotazione ruote (solo grafica)
        val fwd = vx * cos(angle) + vy * sin(angle)
        val rollRate = fwd / v.wheelRadius
        val rearRate = when {
            rearContact -> rollRate
            gas > 0f -> 28f
            brake > 0f -> 0f
            else -> rollRate
        }
        rearSpin += rearRate * dt
        frontSpin += (if (!frontContact && brake > 0f) 0f else rollRate) * dt

        // Caduta: la testa tocca il suolo, o il telaio finisce nel terreno
        val hx = headX(); val hy = headY()
        if (hy - 0.14f < terrain.height(hx) || y - 0.2f < terrain.height(x)) crashed = true
    }

    private fun stepCrashed(dt: Float) {
        vx *= (1f - 1.2f * dt)
        vy -= G * dt
        x += vx * dt
        y += vy * dt
        omega *= (1f - 1.5f * dt)
        angle += omega * dt
        val floor = terrain.height(x) + 0.3f
        if (y < floor) { y = floor; vy = abs(vy) * 0.2f; vx *= 0.9f }
    }

    /** Velocita' (km/h) lungo l'asse del veicolo. */
    fun speedKmh(): Float = abs(vx * cos(angle) + vy * sin(angle)) * 3.6f

    fun dirSign(): Float = sign(vx)
}
