package com.dirtrush.game

import android.content.Context
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class State { MENU, GARAGE, WORLDS, PLAY, PAUSED, OVER }

/** Salvataggi: monete, veicoli sbloccati, selezioni e record. */
class Save(ctx: Context) {
    private val sp = ctx.getSharedPreferences("dirtrush", Context.MODE_PRIVATE)
    var coins: Int
        get() = sp.getInt("coins", 0)
        set(v) { sp.edit().putInt("coins", v).apply() }
    var vehicleId: String
        get() = sp.getString("vehicle", "mx250") ?: "mx250"
        set(v) { sp.edit().putString("vehicle", v).apply() }
    var worldId: String
        get() = sp.getString("world", "desert") ?: "desert"
        set(v) { sp.edit().putString("world", v).apply() }
    fun best(worldId: String): Int = sp.getInt("best_$worldId", 0)
    fun setBest(worldId: String, v: Int) { sp.edit().putInt("best_$worldId", v).apply() }
    fun unlocked(id: String): Boolean = id == "mx250" || sp.getBoolean("unlock_$id", false)
    fun unlock(id: String) { sp.edit().putBoolean("unlock_$id", true).apply() }
}

/** Stato di una corsa e logica di gioco, indipendente dal rendering. */
class Game(private val save: Save) {
    var world: World = Worlds.byId(save.worldId)
    var vehicle: Vehicle = Catalog.byId(save.vehicleId)
    var terrain = Terrain(world.seed, world.roughness)
    var bike = Bike(vehicle, terrain)
    val particles = Particles()
    val coinList = ArrayList<FloatArray>()
    private val collected = HashSet<Int>()
    private var coinsGeneratedTo = 0f

    var camX = 0f; var camY = 0f; var zoom = 1f
    var time = 0f
    var shake = 0f
    var distance = 0f
    var runCoins = 0
    var totalFlips = 0
    var crashTimer = 0f
    var newRecord = false
    var popupText = ""; var popupTimer = 0f
    var earnedTotal = 0
    var finished = false

    fun startRun() {
        world = Worlds.byId(save.worldId)
        vehicle = Catalog.byId(save.vehicleId)
        terrain = Terrain(world.seed, world.roughness)
        bike = Bike(vehicle, terrain)
        coinList.clear(); collected.clear(); coinsGeneratedTo = 0f
        distance = 0f; runCoins = 0; totalFlips = 0; crashTimer = 0f
        newRecord = false; popupTimer = 0f; earnedTotal = 0; finished = false
        camX = bike.x + 3f; camY = bike.y + 1.5f; zoom = 1f; shake = 0f
    }

    private fun popup(s: String) { popupText = s; popupTimer = 1.6f }

    /** Avanza la simulazione di dt secondi (sotto-passi interni). */
    fun update(dt: Float, gas: Float, brake: Float, lean: Float) {
        time += dt
        val steps = max(1, (dt / (1f / 240f)).toInt())
        val h = dt / steps
        for (i in 0 until steps) {
            val wasCrashed = bike.crashed
            bike.step(h, gas, brake, lean)
            if (bike.crashed && !wasCrashed) onCrash()
            if (bike.landed) onLanding()
        }

        distance = max(distance, bike.x)

        // Monete
        if (bike.x + 60f > coinsGeneratedTo) {
            val from = coinsGeneratedTo
            coinsGeneratedTo = bike.x + 120f
            terrain.coinsInRange(from, coinsGeneratedTo, coinList)
        }
        val it = coinList.iterator()
        while (it.hasNext()) {
            val c = it.next()
            if (c[0] < bike.x - 25f) { it.remove(); continue }
            if (!bike.crashed && abs(c[0] - bike.x) < 1.0f && abs(c[1] - bike.y) < 1.2f) {
                if (collected.add(c[2].toInt())) {
                    runCoins++
                    particles.burst(c[0], c[1], 6, 0xFFFFC107.toInt(), 3.5f)
                }
                it.remove()
            }
        }

        // Particelle di polvere dalle ruote
        if (!bike.crashed) {
            val spd = bike.speedKmh() / 3.6f
            if (bike.rearContact && spd > 2f && (time * 60f).toInt() % 2 == 0)
                particles.dust(bike.x - 0.7f, terrain.height(bike.x - 0.7f) + 0.1f, spd, world.dust)
            if (bike.frontContact && gas == 0f && brake > 0f && spd > 3f)
                particles.dust(bike.x + 0.7f, terrain.height(bike.x + 0.7f) + 0.1f, spd, world.dust)
        }
        particles.update(dt)

        // Camera con look-ahead e zoom in base alla velocita'
        val tx = bike.x + bike.vx * 0.30f + 2.5f
        val ty = bike.y + 1.3f
        val k = min(1f, dt * 4.5f)
        camX += (tx - camX) * k
        camY += (ty - camY) * min(1f, dt * 3f)
        val targetZoom = 1f - min(0.25f, bike.speedKmh() / 320f)
        zoom += (targetZoom - zoom) * min(1f, dt * 1.5f)

        shake = max(0f, shake - dt * 2.5f)
        popupTimer = max(0f, popupTimer - dt)

        if (bike.crashed) {
            crashTimer += dt
            if (crashTimer > 1.3f && !finished) finish()
        }
    }

    private fun onLanding() {
        shake = max(shake, bike.landedImpact * 0.8f)
        particles.burst(bike.x, terrain.height(bike.x) + 0.2f, 10, world.dust, 4f)
        if (bike.lastFlips > 0 && !bike.crashed) {
            val n = bike.lastFlips
            totalFlips += n
            val bonus = 25 * n
            runCoins += bonus
            popup(if (n == 1) "FLIP! +$bonus" else "${n}x FLIP! +$bonus")
        }
    }

    private fun onCrash() {
        shake = 1f
        particles.burst(bike.x, bike.y, 18, 0xFFFF7043.toInt(), 6f)
    }

    private fun finish() {
        finished = true
        val metres = distance.toInt()
        earnedTotal = runCoins + metres / 20
        save.coins = save.coins + earnedTotal
        if (metres > save.best(world.id)) {
            save.setBest(world.id, metres)
            newRecord = true
        }
    }

    /** Termina subito (ad esempio dal menu pausa) accreditando le monete. */
    fun abandon() { if (!finished && bike.x > 5f) finish() }
}
