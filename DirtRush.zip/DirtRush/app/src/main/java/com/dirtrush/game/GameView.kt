package com.dirtrush.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    internal val save = Save(context)
    internal val game = Game(save)
    internal var state = State.MENU
    internal val ui = UiKit(resources.displayMetrics.density)
    internal val scene = SceneRenderer()
    internal val renderer = VehicleRenderer()
    internal val buttons = ArrayList<Button>()
    internal var garageIndex = Catalog.vehicles.indexOfFirst { it.id == save.vehicleId }.coerceAtLeast(0)
    internal var menuTime = 0f
    internal var width_ = 0
    internal var height_ = 0

    private val lock = Any()
    private var thread: Thread? = null
    @Volatile private var running = false

    // Input: posizione dei tocchi attivi
    private val maxPointers = 10
    private val px = FloatArray(maxPointers)
    private val py = FloatArray(maxPointers)
    private val active = BooleanArray(maxPointers)
    private var pressedButton: Button? = null

    // Rettangoli dei controlli di gioco
    internal val btnGas = RectF(); internal val btnBrake = RectF()
    internal val btnBack = RectF(); internal val btnFwd = RectF()
    internal val btnPause = RectF()

    private val vignette = Paint()
    private var vignetteShader: Shader? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    // ---------------- ciclo di vita ----------------
    override fun surfaceCreated(h: SurfaceHolder) { start() }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
        synchronized(lock) { width_ = w; height_ = hh; layoutControls(); vignetteShader = null }
    }
    override fun surfaceDestroyed(h: SurfaceHolder) { stop() }

    fun start() {
        if (running) return
        running = true
        thread = Thread(this, "game-loop").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(500)
        thread = null
    }

    fun pause() {
        synchronized(lock) { if (state == State.PLAY) state = State.PAUSED }
        stop()
    }

    private fun layoutControls() {
        val s = ui.dp(86f); val m = ui.dp(22f); val g = ui.dp(14f)
        val w = width_.toFloat(); val h = height_.toFloat()
        btnGas.set(w - m - s, h - m - s, w - m, h - m)
        btnBrake.set(btnGas.left - g - s, h - m - s, btnGas.left - g, h - m)
        btnBack.set(m, h - m - s, m + s, h - m)
        btnFwd.set(btnBack.right + g, h - m - s, btnBack.right + g + s, h - m)
        val ps = ui.dp(46f)
        btnPause.set(w - m - ps, m, w - m, m + ps)
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min(0.033f, (now - last) / 1e9f)
            last = now
            val c = try { holder.lockCanvas() } catch (_: Exception) { null }
            if (c == null) {
                try { Thread.sleep(16) } catch (_: InterruptedException) {}
                last = System.nanoTime()
                continue
            }
            try {
                synchronized(lock) {
                    if (width_ == 0) { width_ = c.width; height_ = c.height; layoutControls() }
                    updateAndDraw(c, dt)
                }
            } finally {
                holder.unlockCanvasAndPost(c)
            }
            val spent = (System.nanoTime() - now) / 1_000_000
            if (spent < 14) try { Thread.sleep(14 - spent) } catch (_: InterruptedException) {}
        }
    }

    // ---------------- logica per frame ----------------
    private fun updateAndDraw(c: Canvas, dt: Float) {
        val w = width_; val h = height_
        menuTime += dt
        buttons.clear()
        when (state) {
            State.PLAY -> {
                var gas = 0f; var brake = 0f; var lean = 0f
                for (i in 0 until maxPointers) {
                    if (!active[i]) continue
                    if (btnGas.contains(px[i], py[i])) gas = 1f
                    if (btnBrake.contains(px[i], py[i])) brake = 1f
                    if (btnBack.contains(px[i], py[i])) lean += 1f
                    if (btnFwd.contains(px[i], py[i])) lean -= 1f
                }
                game.update(dt, gas, brake, lean.coerceIn(-1f, 1f))
                drawPlay(c, w, h, gas > 0f, brake > 0f, lean)
                if (game.finished) state = State.OVER
            }
            State.PAUSED -> { drawPlay(c, w, h, false, false, 0f); drawPaused(c, w, h) }
            State.OVER -> { drawPlay(c, w, h, false, false, 0f); game.particles.update(dt); drawOver(c, w, h) }
            State.MENU -> drawMenu(c, w, h)
            State.GARAGE -> drawGarage(c, w, h)
            State.WORLDS -> drawWorlds(c, w, h)
        }
        for (b in buttons) if (b.visible) ui.button(c, b, b === pressedButton)
    }

    // ---------------- disegno della corsa ----------------
    private fun drawPlay(c: Canvas, w: Int, h: Int, gas: Boolean, brake: Boolean, lean: Float) {
        val world = game.world
        val ppm = h / 9f * game.zoom
        val sx = if (game.shake > 0f) (Math.random().toFloat() - 0.5f) * game.shake * ui.dp(10f) else 0f
        val sy = if (game.shake > 0f) (Math.random().toFloat() - 0.5f) * game.shake * ui.dp(10f) else 0f

        c.save()
        c.translate(sx, sy)
        scene.drawBackground(c, w, h, world, game.camX, ppm, game.time)
        scene.drawGround(c, w, h, game.terrain, world, game.camX, game.camY, ppm)

        // spazio mondo (y invertita)
        c.save()
        c.translate(w / 2f, h / 2f)
        c.scale(ppm, ppm)
        c.translate(-game.camX, game.camY)

        // monete
        for (co in game.coinList) {
            val spin = abs(cos(game.time * 4f + co[2]))
            p.style = Paint.Style.FILL
            p.color = 0xFFFFB300.toInt()
            c.drawOval(co[0] - 0.26f * spin - 0.05f, -co[1] - 0.3f, co[0] + 0.26f * spin + 0.05f, -co[1] + 0.3f, p)
            p.color = 0xFFFFE082.toInt()
            c.drawOval(co[0] - 0.16f * spin, -co[1] - 0.2f, co[0] + 0.16f * spin, -co[1] + 0.2f, p)
        }

        val b = game.bike
        // ombra sul terreno
        val gh = game.terrain.height(b.x)
        val alt = max(0f, b.y - gh - 0.7f)
        p.color = 0x55000000
        val sw = 0.9f / (1f + alt * 0.4f)
        c.drawOval(b.x - sw, -gh - 0.07f, b.x + sw, -gh + 0.05f, p)

        // faro nel mondo notturno
        if (world.night && !b.crashed) {
            c.save()
            c.translate(b.x, -b.y)
            c.rotate(-Math.toDegrees(b.angle.toDouble()).toFloat())
            val fx = game.vehicle.wheelbase / 2f
            path.reset(); path.moveTo(fx, -0.2f); path.lineTo(fx + 7f, -1.8f); path.lineTo(fx + 7f, 1.6f); path.close()
            p.shader = LinearGradient(fx, 0f, fx + 7f, 0f, 0x66FFF6B0, 0x00FFF6B0, Shader.TileMode.CLAMP)
            c.drawPath(path, p)
            p.shader = null
            c.restore()
        }

        // veicolo
        c.save()
        c.translate(b.x, -b.y)
        c.rotate(-Math.toDegrees(b.angle.toDouble()).toFloat())
        renderer.draw(c, game.vehicle, b.rearSpin, b.frontSpin, b.rearPen, b.frontPen, b.crashed,
            if (lean != 0f) lean else 0f)
        c.restore()

        game.particles.draw(c)
        c.restore()
        c.restore()

        // linee di velocita'
        val spd = b.speedKmh()
        if (spd > 55f && !b.crashed) {
            p.color = 0x33FFFFFF
            p.strokeWidth = ui.dp(2f)
            for (i in 0 until 9) {
                val yy = h * ((i * 0.137f + 0.07f) % 1f)
                val xx = ((game.time * 900f * (0.6f + (i % 3) * 0.3f) + i * 230f) % (w + 200f))
                val len = min(220f, spd * 1.6f)
                c.drawLine(w - xx, yy, w - xx + len, yy, p)
            }
        }

        // vignettatura
        if (vignetteShader == null) {
            vignetteShader = RadialGradient(w / 2f, h / 2f, max(w, h) * 0.72f, 0x00000000, 0x77000000, Shader.TileMode.CLAMP)
        }
        vignette.shader = vignetteShader
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vignette)

        if (state == State.PLAY || state == State.PAUSED) drawHud(c, w, h, gas, brake, lean)
    }

    private fun drawHud(c: Canvas, w: Int, h: Int, gas: Boolean, brake: Boolean, lean: Float) {
        val m = ui.dp(22f)
        val b = game.bike
        // pannello distanza
        val panel = RectF(m, m, m + ui.dp(190f), m + ui.dp(62f))
        ui.panel(c, panel)
        ui.text(c, "${game.distance.toInt()} m", panel.left + ui.dp(16f), panel.top + ui.dp(30f), ui.dp(26f), heavyFont = true)
        ui.text(c, "RECORD ${max(save.best(game.world.id), game.distance.toInt())} m",
            panel.left + ui.dp(16f), panel.top + ui.dp(50f), ui.dp(12f), 0xFFB8C2DA.toInt(), shadow = false)
        // monete
        val cp = RectF(w / 2f - ui.dp(60f), m, w / 2f + ui.dp(60f), m + ui.dp(44f))
        ui.panel(c, cp)
        ui.coinIcon(c, cp.left + ui.dp(24f), cp.centerY(), ui.dp(12f))
        ui.text(c, "${game.runCoins}", cp.left + ui.dp(44f), cp.centerY() + ui.dp(8f), ui.dp(22f), heavyFont = true)

        // pausa
        ui.panel(c, btnPause)
        val pc = btnPause.centerX(); val pcy = btnPause.centerY()
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt()
        c.drawRect(pc - ui.dp(9f), pcy - ui.dp(10f), pc - ui.dp(3f), pcy + ui.dp(10f), p)
        c.drawRect(pc + ui.dp(3f), pcy - ui.dp(10f), pc + ui.dp(9f), pcy + ui.dp(10f), p)

        // tachimetro
        val kmh = b.speedKmh().toInt()
        ui.text(c, "$kmh", w / 2f, h - m - ui.dp(16f), ui.dp(34f), 0xFFFFFFFF.toInt(), Paint.Align.CENTER, heavyFont = true)
        ui.text(c, "KM/H", w / 2f, h - m + ui.dp(2f), ui.dp(12f), 0xFFB8C2DA.toInt(), Paint.Align.CENTER, shadow = false)

        // controlli
        control(c, btnGas, "GAS", gas, 0xFF43A047.toInt())
        control(c, btnBrake, "FRENO", brake, 0xFFE53935.toInt())
        control(c, btnBack, "MUSO SU", lean > 0.5f, 0xFF1E88E5.toInt())
        control(c, btnFwd, "MUSO GIU", lean < -0.5f, 0xFF1E88E5.toInt())

        // popup acrobazie
        if (game.popupTimer > 0f) {
            val t = game.popupTimer / 1.6f
            val size = ui.dp(34f) * (1f + (1f - t) * 0.15f)
            val col = (((t * 255).toInt().coerceIn(0, 255)) shl 24) or 0xFFD54F
            ui.text(c, game.popupText, w / 2f, h * 0.30f - (1f - t) * ui.dp(30f), size, col, Paint.Align.CENTER, heavyFont = true, shadow = false)
        }
    }

    private fun control(c: Canvas, r: RectF, label: String, on: Boolean, color: Int) {
        p.style = Paint.Style.FILL
        p.color = if (on) (0xDD000000.toInt() or (color and 0xFFFFFF)) else 0x66000000
        c.drawOval(r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = ui.dp(3f)
        p.color = (0xFF000000.toInt() or (color and 0xFFFFFF))
        c.drawOval(r, p)
        p.style = Paint.Style.FILL
        ui.text(c, label, r.centerX(), r.centerY() + ui.dp(5f), ui.dp(if (label.length > 5) 12f else 16f), 0xFFFFFFFF.toInt(), Paint.Align.CENTER)
    }

    // ---------------- input ----------------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        synchronized(lock) {
            val action = e.actionMasked
            when (action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val i = e.actionIndex
                    val id = e.getPointerId(i)
                    if (id < maxPointers) { px[id] = e.getX(i); py[id] = e.getY(i); active[id] = true }
                    onPress(e.getX(i), e.getY(i))
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until e.pointerCount) {
                        val id = e.getPointerId(i)
                        if (id < maxPointers) { px[id] = e.getX(i); py[id] = e.getY(i) }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                    val i = e.actionIndex
                    val id = e.getPointerId(i)
                    if (id < maxPointers) active[id] = false
                    if (action == MotionEvent.ACTION_CANCEL) active.fill(false)
                    val pb = pressedButton
                    if (pb != null && action != MotionEvent.ACTION_CANCEL && pb.rect.contains(e.getX(i), e.getY(i))) {
                        pressedButton = null
                        if (pb.enabled) pb.action()
                    }
                    pressedButton = null
                }
            }
        }
        return true
    }

    private fun onPress(x: Float, y: Float) {
        if ((state == State.PLAY) && btnPause.contains(x, y)) { state = State.PAUSED; active.fill(false); return }
        pressedButton = buttons.firstOrNull { it.rect.contains(x, y) }
    }

    // ---------------- azioni ----------------
    internal fun startGame() { game.startRun(); active.fill(false); state = State.PLAY }

    fun handleBack(): Boolean = synchronized(lock) {
        when (state) {
            State.PLAY -> { state = State.PAUSED; active.fill(false); true }
            State.PAUSED -> { state = State.PLAY; true }
            State.GARAGE, State.WORLDS, State.OVER -> { state = State.MENU; true }
            State.MENU -> false
        }
    }

    internal fun sky(c: Canvas, w: Int, h: Int) {
        val ppm = h / 9f
        val cx = menuTime * 3f
        val cy = game.terrain.height(cx) + 1.5f
        scene.drawBackground(c, w, h, game.world, cx, ppm, menuTime)
        scene.drawGround(c, w, h, game.terrain, game.world, cx, cy, ppm)
    }
}
