package com.dirtrush.game

import android.graphics.Canvas
import android.graphics.Paint
import kotlin.random.Random

/** Particelle (polvere, terra, scintille, monete) con pool fisso: nessuna allocazione per frame. */
class Particles(private val max: Int = 400) {
    private val x = FloatArray(max); private val y = FloatArray(max)
    private val vx = FloatArray(max); private val vy = FloatArray(max)
    private val life = FloatArray(max); private val total = FloatArray(max)
    private val size = FloatArray(max); private val color = IntArray(max)
    private val grav = FloatArray(max)
    private var next = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun emit(px: Float, py: Float, pvx: Float, pvy: Float, life: Float, size: Float, color: Int, gravity: Float) {
        val i = next
        next = (next + 1) % max
        x[i] = px; y[i] = py; vx[i] = pvx; vy[i] = pvy
        this.life[i] = life; total[i] = life; this.size[i] = size; this.color[i] = color; grav[i] = gravity
    }

    fun dust(px: Float, py: Float, speed: Float, color: Int) {
        val r = Random
        emit(px, py, -speed * 0.15f + r.nextFloat() * 1.2f - 0.6f, 0.8f + r.nextFloat() * 1.4f,
            0.5f + r.nextFloat() * 0.4f, 0.10f + r.nextFloat() * 0.14f, color, -0.5f)
    }

    fun burst(px: Float, py: Float, n: Int, color: Int, power: Float) {
        val r = Random
        for (i in 0 until n) {
            val a = r.nextFloat() * 6.2831855f
            val s = power * (0.3f + r.nextFloat())
            emit(px, py, kotlin.math.cos(a) * s, kotlin.math.sin(a) * s + power * 0.3f,
                0.5f + r.nextFloat() * 0.5f, 0.06f + r.nextFloat() * 0.08f, color, 9f)
        }
    }

    fun update(dt: Float) {
        for (i in 0 until max) {
            if (life[i] <= 0f) continue
            life[i] -= dt
            vy[i] -= grav[i] * dt
            x[i] += vx[i] * dt
            y[i] += vy[i] * dt
        }
    }

    /** Disegna in coordinate mondo (il chiamante ha gia' applicato la camera, y invertita). */
    fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until max) {
            if (life[i] <= 0f) continue
            val t = life[i] / total[i]
            p.color = color[i]
            p.alpha = (t * 190).toInt().coerceIn(0, 255)
            c.drawCircle(x[i], -y[i], size[i] * (1.6f - t * 0.6f), p)
        }
        p.alpha = 255
    }
}
