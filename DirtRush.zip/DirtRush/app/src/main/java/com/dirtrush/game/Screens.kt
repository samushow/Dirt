package com.dirtrush.game

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.sin

// Schermate del gioco, disegnate sopra la scena panoramica.

private val dimPaint = Paint()
private val tmp = Paint(Paint.ANTI_ALIAS_FLAG)
private val tmpPath = Path()

private fun GameView.dim(c: Canvas, w: Int, h: Int, alpha: Int) {
    dimPaint.color = (alpha shl 24)
    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), dimPaint)
}

private fun GameView.btn(cx: Float, cy: Float, bw: Float, bh: Float, label: String,
                         enabled: Boolean = true, primary: Boolean = false, action: () -> Unit) {
    buttons.add(Button(RectF(cx - bw / 2f, cy - bh / 2f, cx + bw / 2f, cy + bh / 2f), label, enabled, primary, true, action))
}

private fun GameView.coinsBadge(c: Canvas, w: Int) {
    val m = ui.dp(22f)
    val r = RectF(w - m - ui.dp(130f), m, w - m, m + ui.dp(44f))
    ui.panel(c, r)
    ui.coinIcon(c, r.left + ui.dp(24f), r.centerY(), ui.dp(12f))
    ui.text(c, "${save.coins}", r.left + ui.dp(44f), r.centerY() + ui.dp(8f), ui.dp(22f), heavyFont = true)
}

/** Veicolo su una pedana: usato in menu e garage. */
private fun GameView.showcase(c: Canvas, v: Vehicle, cx: Float, cy: Float, scale: Float) {
    // pedana
    tmp.style = Paint.Style.FILL
    tmp.shader = null
    tmp.color = 0x55000000
    c.drawOval(cx - scale * 1.5f, cy + scale * 0.62f, cx + scale * 1.5f, cy + scale * 0.92f, tmp)
    tmp.shader = LinearGradient(0f, cy + scale * 0.66f, 0f, cy + scale * 0.80f, 0xFF4A5470.toInt(), 0xFF22283B.toInt(), Shader.TileMode.CLAMP)
    c.drawOval(cx - scale * 1.35f, cy + scale * 0.64f, cx + scale * 1.35f, cy + scale * 0.84f, tmp)
    tmp.shader = null

    val bob = sin(menuTime * 2.2f) * 0.015f
    val spin = menuTime * 6f
    c.save()
    c.translate(cx, cy + scale * bob)
    c.scale(scale, scale)
    renderer.draw(c, v, spin, spin, 0.04f, 0.04f, false, 0f)
    c.restore()
}

internal fun GameView.drawMenu(c: Canvas, w: Int, h: Int) {
    sky(c, w, h)
    dim(c, w, h, 70)
    val v = Catalog.byId(save.vehicleId)
    showcase(c, v, w * 0.27f, h * 0.58f, h / 5.4f)

    ui.title(c, "DIRT RUSH", w * 0.70f, h * 0.26f, ui.dp(52f))
    ui.text(c, "MOTO & QUAD FREESTYLE", w * 0.70f, h * 0.26f + ui.dp(26f), ui.dp(14f), 0xFFFFD180.toInt(), Paint.Align.CENTER)

    val bw = ui.dp(240f); val bh = ui.dp(54f)
    val cx = w * 0.70f
    btn(cx, h * 0.46f, bw, bh, "GIOCA", primary = true) { startGame() }
    btn(cx, h * 0.46f + bh * 1.25f, bw, bh, "GARAGE") { state = State.GARAGE }
    btn(cx, h * 0.46f + bh * 2.5f, bw, bh, "MONDI") { state = State.WORLDS }

    ui.text(c, "${game.world.name}  -  ${v.name}", cx, h * 0.46f + bh * 3.5f, ui.dp(14f), 0xFFE0E6F5.toInt(), Paint.Align.CENTER)
    coinsBadge(c, w)
}

internal fun GameView.drawGarage(c: Canvas, w: Int, h: Int) {
    sky(c, w, h)
    dim(c, w, h, 120)
    val list = Catalog.vehicles
    val v = list[garageIndex]
    val unlocked = save.unlocked(v.id)

    ui.title(c, "GARAGE", w * 0.5f, ui.dp(52f), ui.dp(34f))
    coinsBadge(c, w)

    val cx = w * 0.33f
    showcase(c, v, cx, h * 0.52f, h / 4.4f)
    // nome e categoria
    ui.text(c, v.name, cx, h * 0.84f, ui.dp(24f), 0xFFFFFFFF.toInt(), Paint.Align.CENTER, heavyFont = true)
    val kind = if (v.type == VehicleType.MOTO) "MOTO" else "QUAD"
    ui.text(c, "$kind  -  ${styleName(v.style)}", cx, h * 0.84f + ui.dp(20f), ui.dp(13f), 0xFFFFD180.toInt(), Paint.Align.CENTER)

    // frecce
    val ah = ui.dp(60f)
    btn(w * 0.07f, h * 0.52f, ui.dp(56f), ah, "<") { garageIndex = (garageIndex - 1 + list.size) % list.size }
    btn(w * 0.59f, h * 0.52f, ui.dp(56f), ah, ">") { garageIndex = (garageIndex + 1) % list.size }

    // pagina
    for (i in list.indices) {
        tmp.style = Paint.Style.FILL
        tmp.color = if (i == garageIndex) 0xFFFF9A2E.toInt() else 0x55FFFFFF
        c.drawCircle(cx + (i - (list.size - 1) / 2f) * ui.dp(14f), h * 0.84f + ui.dp(40f), ui.dp(4f), tmp)
    }

    // pannello statistiche
    val pr = RectF(w * 0.66f, h * 0.22f, w - ui.dp(22f), h * 0.74f)
    ui.panel(c, pr)
    val sx = pr.left + ui.dp(18f); val sw = pr.width() - ui.dp(36f)
    var y = pr.top + ui.dp(34f)
    val gap = ui.dp(34f)
    ui.statBar(c, "POTENZA", v.power / 12f, sx, y, sw, 0xFFFF7043.toInt()); y += gap
    ui.statBar(c, "ADERENZA", v.grip / 1.6f, sx, y, sw, 0xFF66BB6A.toInt()); y += gap
    ui.statBar(c, "EQUILIBRIO", v.stability / 1.5f, sx, y, sw, 0xFF42A5F5.toInt()); y += gap
    ui.statBar(c, "SOSPENSIONI", v.suspension / 1.5f, sx, y, sw, 0xFFAB47BC.toInt()); y += gap
    ui.statBar(c, "PESO", v.mass / 230f, sx, y, sw, 0xFFFFCA28.toInt())

    val selected = save.vehicleId == v.id
    val label: String; val enabled: Boolean
    when {
        selected -> { label = "IN USO"; enabled = false }
        unlocked -> { label = "SELEZIONA"; enabled = true }
        save.coins >= v.price -> { label = "SBLOCCA  ${v.price}"; enabled = true }
        else -> { label = "SERVONO ${v.price}"; enabled = false }
    }
    btn(pr.centerX(), h * 0.74f + ui.dp(46f), pr.width() - ui.dp(20f), ui.dp(54f), label, enabled, primary = true) {
        if (!unlocked) { save.coins = save.coins - v.price; save.unlock(v.id) }
        save.vehicleId = v.id
        game.vehicle = v
    }
    btn(ui.dp(90f), h - ui.dp(46f), ui.dp(140f), ui.dp(48f), "INDIETRO") { state = State.MENU }
}

private fun styleName(s: Style) = when (s) {
    Style.MOTOCROSS -> "MOTOCROSS"
    Style.ENDURO -> "ENDURO"
    Style.TRIAL -> "TRIAL"
    Style.SPORT -> "SUPERMOTO"
    Style.QUAD_SPORT -> "QUAD SPORT"
    Style.QUAD_UTILITY -> "QUAD 4x4"
}

internal fun GameView.drawWorlds(c: Canvas, w: Int, h: Int) {
    sky(c, w, h)
    dim(c, w, h, 140)
    ui.title(c, "SCEGLI IL MONDO", w * 0.5f, ui.dp(52f), ui.dp(34f))
    coinsBadge(c, w)

    val worlds = Worlds.all
    val margin = ui.dp(28f); val gap = ui.dp(14f)
    val cw = (w - margin * 2 - gap * (worlds.size - 1)) / worlds.size
    val top = h * 0.22f; val bottom = h * 0.80f
    for ((i, wd) in worlds.withIndex()) {
        val r = RectF(margin + i * (cw + gap), top, margin + i * (cw + gap) + cw, bottom)
        tmp.style = Paint.Style.FILL
        tmp.shader = LinearGradient(0f, r.top, 0f, r.bottom, wd.skyTop, wd.skyBottom, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, ui.dp(18f), ui.dp(18f), tmp)
        tmp.shader = null
        // silhouette montagne
        c.save()
        c.clipRect(r)
        for ((li, col) in listOf(wd.far, wd.mid, wd.near).withIndex()) {
            tmpPath.reset()
            tmpPath.moveTo(r.left, r.bottom)
            var x = r.left
            while (x <= r.right + 10f) {
                val t = (x - r.left) / r.width()
                val y = r.bottom - r.height() * (0.34f - li * 0.07f) - sin(t * 6f + li * 2f + i) * r.height() * 0.07f
                tmpPath.lineTo(x, y)
                x += 10f
            }
            tmpPath.lineTo(r.right, r.bottom)
            tmpPath.close()
            tmp.color = col
            c.drawPath(tmpPath, tmp)
        }
        tmp.color = wd.soilTop
        c.drawRect(r.left, r.bottom - r.height() * 0.12f, r.right, r.bottom, tmp)
        tmp.color = wd.grass
        c.drawRect(r.left, r.bottom - r.height() * 0.12f, r.right, r.bottom - r.height() * 0.12f + ui.dp(5f), tmp)
        c.restore()

        val sel = save.worldId == wd.id
        tmp.style = Paint.Style.STROKE
        tmp.strokeWidth = ui.dp(if (sel) 4f else 1.5f)
        tmp.color = if (sel) 0xFFFF9A2E.toInt() else 0x66FFFFFF
        c.drawRoundRect(r, ui.dp(18f), ui.dp(18f), tmp)
        tmp.style = Paint.Style.FILL

        ui.text(c, wd.name, r.centerX(), r.top + ui.dp(34f), ui.dp(17f), 0xFFFFFFFF.toInt(), Paint.Align.CENTER, heavyFont = true)
        ui.text(c, "RECORD ${save.best(wd.id)} m", r.centerX(), r.top + ui.dp(56f), ui.dp(12f), 0xFFFFFFFF.toInt(), Paint.Align.CENTER)
        if (sel) ui.text(c, "SELEZIONATO", r.centerX(), r.bottom - ui.dp(16f), ui.dp(12f), 0xFFFFD180.toInt(), Paint.Align.CENTER)

        buttons.add(Button(r, "", true, false, false) {
            save.worldId = wd.id
            game.world = wd
            game.terrain = Terrain(wd.seed, wd.roughness)
        })
    }
    btn(ui.dp(90f), h - ui.dp(46f), ui.dp(140f), ui.dp(48f), "INDIETRO") { state = State.MENU }
}

internal fun GameView.drawPaused(c: Canvas, w: Int, h: Int) {
    dim(c, w, h, 150)
    val pr = RectF(w / 2f - ui.dp(170f), h / 2f - ui.dp(120f), w / 2f + ui.dp(170f), h / 2f + ui.dp(120f))
    ui.panel(c, pr, 200)
    ui.title(c, "PAUSA", w / 2f, pr.top + ui.dp(52f), ui.dp(32f))
    btn(w / 2f, pr.top + ui.dp(120f), ui.dp(240f), ui.dp(54f), "RIPRENDI", primary = true) { state = State.PLAY }
    btn(w / 2f, pr.top + ui.dp(188f), ui.dp(240f), ui.dp(48f), "ESCI AL MENU") { game.abandon(); state = State.MENU }
}

internal fun GameView.drawOver(c: Canvas, w: Int, h: Int) {
    dim(c, w, h, 160)
    val pr = RectF(w / 2f - ui.dp(210f), h / 2f - ui.dp(150f), w / 2f + ui.dp(210f), h / 2f + ui.dp(150f))
    ui.panel(c, pr, 210)
    ui.title(c, if (game.newRecord) "NUOVO RECORD!" else "CORSA FINITA", w / 2f, pr.top + ui.dp(46f), ui.dp(30f))
    val lx = pr.left + ui.dp(40f); val rx = pr.right - ui.dp(40f)
    var y = pr.top + ui.dp(84f)
    fun row(label: String, value: String) {
        ui.text(c, label, lx, y, ui.dp(16f), 0xFFB8C2DA.toInt())
        ui.text(c, value, rx, y, ui.dp(20f), 0xFFFFFFFF.toInt(), Paint.Align.RIGHT, heavyFont = true)
        y += ui.dp(30f)
    }
    row("DISTANZA", "${game.distance.toInt()} m")
    row("ACROBAZIE", "${game.totalFlips} flip")
    row("MONETE GUADAGNATE", "+${game.earnedTotal}")
    row("TOTALE", "${save.coins}")

    val by = pr.bottom - ui.dp(40f)
    btn(w / 2f - ui.dp(135f), by, ui.dp(120f), ui.dp(48f), "RIPROVA", primary = true) { startGame() }
    btn(w / 2f, by, ui.dp(120f), ui.dp(48f), "GARAGE") { state = State.GARAGE }
    btn(w / 2f + ui.dp(135f), by, ui.dp(120f), ui.dp(48f), "MENU") { state = State.MENU }
}
