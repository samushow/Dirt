package com.dirtrush.game

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Terreno procedurale infinito (coordinate in metri, y verso l'alto).
 * La difficolta' cresce con la distanza; ogni tanto compaiono rampe e salti.
 */
class Terrain(private val seed: Int, private val roughness: Float) {

    private val p1 = 0.8f + (seed % 7) * 0.05f
    private val p2 = 1.9f + (seed % 5) * 0.07f
    private val p3 = 4.3f + (seed % 3) * 0.11f

    // Salti: ogni "slot" di 70 m contiene al massimo una rampa
    private val slot = 70f

    private fun hash(n: Int): Float {
        var x = n * 374761393 + seed * 668265263
        x = (x xor (x ushr 13)) * 1274126177
        x = x xor (x ushr 16)
        return (x and 0xFFFF) / 65535f
    }

    private fun smooth(t: Float) = t * t * (3 - 2 * t)

    /** Altezza del suolo a x. */
    fun height(x: Float): Float {
        if (x < 0f) return startFlat(x)
        val diff = 1f + (x / 1500f).coerceAtMost(1.2f)
        val amp = roughness * diff
        var h = 0f
        h += sin(x * 0.045f * p1) * 2.6f * amp
        h += sin(x * 0.11f * p2 + 1.3f) * 1.0f * amp
        h += sin(x * 0.27f * p3 + 0.4f) * 0.22f * amp
        // dolce partenza: i primi 25 m sono quasi piatti
        val ease = smooth((x / 25f).coerceIn(0f, 1f))
        h *= ease
        h += jump(x)
        return h
    }

    private fun startFlat(x: Float) = 0f

    /** Rampa + buca: profilo a "kicker" seguito da una discesa. */
    private fun jump(x: Float): Float {
        if (x < 60f) return 0f
        val idx = (x / slot).toInt()
        if (hash(idx) < 0.45f) return 0f
        val start = idx * slot + 12f + hash(idx + 91) * 20f
        val len = 7f + hash(idx + 17) * 5f
        val ht = 1.4f + hash(idx + 5) * 1.6f
        val t = (x - start) / len
        return when {
            t < 0f || t > 2.1f -> 0f
            t <= 1f -> ht * smooth(t) * t            // salita ripida
            t <= 1.1f -> ht                          // lip
            else -> ht * (1f - smooth(((t - 1.1f) / 1f).coerceIn(0f, 1f)))
        }
    }

    /** Pendenza dh/dx (differenza centrale). */
    fun slope(x: Float): Float = (height(x + 0.15f) - height(x - 0.15f)) / 0.3f

    /** Normale unitaria (nx, ny) con ny > 0. */
    fun normal(x: Float, out: FloatArray) {
        val s = slope(x)
        val inv = 1f / sqrt(s * s + 1f)
        out[0] = -s * inv
        out[1] = inv
    }

    /** Posizione delle monete: gruppi ogni ~35 m, sempre sopra il terreno. */
    fun coinsInRange(x0: Float, x1: Float, out: MutableList<FloatArray>) {
        val step = 35f
        var i = max(2, (x0 / step).toInt() - 1)
        while (i * step < x1) {
            val h = hash(i + 4000)
            if (h > 0.35f) {
                val n = 3 + (hash(i + 4100) * 4).toInt()
                val bx = i * step + hash(i + 4200) * 10f
                for (k in 0 until n) {
                    val cx = bx + k * 1.6f
                    val arc = sin(PI.toFloat() * k / max(1, n - 1)) * 1.2f
                    out.add(floatArrayOf(cx, height(cx) + 1.1f + arc, (i * 10 + k).toFloat()))
                }
            }
            i++
        }
    }

    fun isRamp(x: Float) = abs(jump(x)) > 0.05f
}
