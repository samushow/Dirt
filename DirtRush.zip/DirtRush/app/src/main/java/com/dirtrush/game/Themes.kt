package com.dirtrush.game

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.sin

data class World(
    val id: String,
    val name: String,
    val skyTop: Int,
    val skyBottom: Int,
    val far: Int,
    val mid: Int,
    val near: Int,
    val soilTop: Int,
    val soilBottom: Int,
    val grass: Int,
    val sun: Int,
    val night: Boolean,
    val roughness: Float,
    val seed: Int,
    val dust: Int
)

object Worlds {
    private fun c(hex: Long) = (0xFF000000L or hex).toInt()

    val all = listOf(
        World("desert", "Deserto Dorato",
            c(0x2B6CB0), c(0xFFD79A), c(0xD9A066), c(0xC98A4B), c(0xB5733A),
            c(0xC9843C), c(0x6E3F1C), c(0xE8B45A), c(0xFFF3C4), false, 1.0f, 11, c(0xE3B97A)),
        World("forest", "Foresta Verde",
            c(0x4FA3E0), c(0xDFF3E4), c(0x7FB69A), c(0x4F9A6E), c(0x2F7A4B),
            c(0x6B4A2B), c(0x2E1D10), c(0x3FBF4F), c(0xFFFFFF), false, 1.15f, 23, c(0x9C7A55)),
        World("snow", "Montagne Innevate",
            c(0x6E9BD1), c(0xEAF4FF), c(0xB9CCE6), c(0x9DB5D6), c(0x7E9AC2),
            c(0xE9F2FA), c(0x7C93B0), c(0xFFFFFF), c(0xFFFFFF), false, 1.3f, 37, c(0xFFFFFF)),
        World("neon", "Notte Neon",
            c(0x0B0B2E), c(0x7B1FA2), c(0x2A1A5E), c(0x3B1F7A), c(0x1A1040),
            c(0x2B1B4D), c(0x0E0A22), c(0x00E5FF), c(0xFFE0F7), true, 1.1f, 53, c(0xB388FF))
    )

    fun byId(id: String): World = all.firstOrNull { it.id == id } ?: all[0]
}

/** Disegna cielo, montagne con parallasse, nuvole e terreno. */
class SceneRenderer {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var skyShader: Shader? = null
    private var skyKey = ""

    private fun layer(c: Canvas, w: Int, h: Int, camX: Float, ppm: Float,
                      factor: Float, baseY: Float, amp: Float, freq: Float, phase: Float, color: Int) {
        path.reset()
        path.moveTo(0f, h.toFloat())
        var px = 0
        while (px <= w + 16) {
            val wx = camX * factor + (px - w / 2f) / ppm * factor * 0.6f
            val y = baseY - amp * (sin(wx * freq + phase) + 0.55f * sin(wx * freq * 2.3f + phase * 1.7f) + 0.25f * sin(wx * freq * 5.1f))
            path.lineTo(px.toFloat(), y)
            px += 14
        }
        path.lineTo(w.toFloat(), h.toFloat())
        path.close()
        p.shader = null
        p.color = color
        c.drawPath(path, p)
    }

    fun drawBackground(c: Canvas, w: Int, h: Int, world: World, camX: Float, ppm: Float, time: Float) {
        val key = "${world.id}-$h"
        if (key != skyKey) {
            skyShader = LinearGradient(0f, 0f, 0f, h.toFloat(), world.skyTop, world.skyBottom, Shader.TileMode.CLAMP)
            skyKey = key
        }
        p.shader = skyShader
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = null

        // Sole / luna con alone
        val sx = w * 0.78f; val sy = h * 0.22f
        p.shader = RadialGradient(sx, sy, h * 0.28f, world.sun and 0x00FFFFFF or 0x88000000.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(sx, sy, h * 0.28f, p)
        p.shader = null
        p.color = world.sun
        c.drawCircle(sx, sy, h * 0.065f, p)

        // Stelle per mondo notturno
        if (world.night) {
            p.color = 0xFFFFFFFF.toInt()
            for (i in 0 until 60) {
                val x = (i * 97 % 1000) / 1000f * w
                val y = (i * 53 % 1000) / 1000f * h * 0.55f
                val tw = 0.5f + 0.5f * sin(time * 2f + i)
                p.alpha = (80 + 140 * tw).toInt()
                c.drawCircle(x, y, 1.2f + (i % 3), p)
            }
            p.alpha = 255
        }

        // Nuvole
        p.color = if (world.night) 0x22FFFFFF else 0x66FFFFFF
        for (i in 0 until 5) {
            val cx = ((i * 330f - camX * 6f * (0.4f + i * 0.08f) + time * 6f) % (w + 400f) + (w + 400f)) % (w + 400f) - 200f
            val cy = h * (0.12f + 0.07f * i)
            c.drawOval(cx - 90f, cy - 20f, cx + 90f, cy + 20f, p)
            c.drawOval(cx - 50f, cy - 36f, cx + 50f, cy + 8f, p)
        }

        // Tre livelli di montagne (parallasse)
        layer(c, w, h, camX, ppm, 0.12f, h * 0.55f, h * 0.16f, 0.045f, 1f, world.far)
        layer(c, w, h, camX, ppm, 0.25f, h * 0.64f, h * 0.12f, 0.07f, 2f, world.mid)
        layer(c, w, h, camX, ppm, 0.42f, h * 0.74f, h * 0.08f, 0.11f, 4f, world.near)
    }

    fun drawGround(c: Canvas, w: Int, h: Int, terrain: Terrain, world: World,
                   camX: Float, camY: Float, ppm: Float) {
        path.reset()
        path.moveTo(0f, h.toFloat())
        var px = 0
        var firstY = 0f
        while (px <= w + 6) {
            val wx = camX + (px - w / 2f) / ppm
            val sy = h / 2f - (terrain.height(wx) - camY) * ppm
            if (px == 0) firstY = sy
            path.lineTo(px.toFloat(), sy)
            px += 6
        }
        path.lineTo(w.toFloat() + 6f, h.toFloat())
        path.close()

        p.shader = LinearGradient(0f, h * 0.35f, 0f, h.toFloat(), world.soilTop, world.soilBottom, Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.shader = null

        // Strati di terra piu' scuri (profondita')
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = world.soilBottom and 0x00FFFFFF or 0x55000000
        c.save()
        c.translate(0f, 38f)
        c.drawPath(path, p)
        c.translate(0f, 56f)
        c.drawPath(path, p)
        c.restore()

        // Bordo erboso / sabbioso e ombra interna
        p.strokeWidth = 12f
        p.color = world.grass
        p.strokeJoin = Paint.Join.ROUND
        path.reset()
        px = 0
        while (px <= w + 6) {
            val wx = camX + (px - w / 2f) / ppm
            val sy = h / 2f - (terrain.height(wx) - camY) * ppm
            if (px == 0) path.moveTo(px.toFloat(), sy + 4f) else path.lineTo(px.toFloat(), sy + 4f)
            px += 6
        }
        c.drawPath(path, p)
        p.strokeWidth = 3f
        p.color = 0x44000000
        c.save(); c.translate(0f, 12f); c.drawPath(path, p); c.restore()
        p.style = Paint.Style.FILL
    }
}
