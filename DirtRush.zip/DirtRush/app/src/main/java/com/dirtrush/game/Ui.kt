package com.dirtrush.game

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface

class Button(
    val rect: RectF,
    val label: String,
    val enabled: Boolean = true,
    val primary: Boolean = false,
    val visible: Boolean = true,
    val action: () -> Unit
)

/** Piccolo kit grafico per menu e HUD: pannelli vetro, pulsanti con gradiente, barre statistica. */
class UiKit(private val density: Float) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    private val heavy = Typeface.create("sans-serif-black", Typeface.NORMAL)

    fun dp(v: Float) = v * density

    fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = 0xFFFFFFFF.toInt(),
             align: Paint.Align = Paint.Align.LEFT, heavyFont: Boolean = false, shadow: Boolean = true) {
        p.style = Paint.Style.FILL
        p.typeface = if (heavyFont) heavy else bold
        p.textSize = size
        p.textAlign = align
        if (shadow) {
            p.color = 0x88000000.toInt()
            c.drawText(s, x + size * 0.05f, y + size * 0.06f, p)
        }
        p.color = color
        c.drawText(s, x, y, p)
    }

    fun panel(c: Canvas, rect: RectF, alpha: Int = 140, radius: Float = dp(16f)) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = (alpha shl 24) or 0x0D1020
        c.drawRoundRect(rect, radius, radius, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(1.5f)
        p.color = 0x44FFFFFF
        c.drawRoundRect(rect, radius, radius, p)
        p.style = Paint.Style.FILL
    }

    fun button(c: Canvas, b: Button, pressed: Boolean = false) {
        val rad = b.rect.height() * 0.3f
        p.style = Paint.Style.FILL
        val top: Int; val bottom: Int
        when {
            !b.enabled -> { top = 0xFF555A66.toInt(); bottom = 0xFF3A3E48.toInt() }
            b.primary -> { top = 0xFFFF9A2E.toInt(); bottom = 0xFFE5530A.toInt() }
            else -> { top = 0xFF4A5470.toInt(); bottom = 0xFF2A3148.toInt() }
        }
        r.set(b.rect)
        if (pressed) r.inset(dp(2f), dp(2f))
        // ombra
        p.shader = null
        p.color = 0x55000000
        c.drawRoundRect(r.left, r.top + dp(4f), r.right, r.bottom + dp(4f), rad, rad, p)
        p.shader = LinearGradient(0f, r.top, 0f, r.bottom, top, bottom, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(1.5f)
        p.color = 0x55FFFFFF
        c.drawRoundRect(r, rad, rad, p)
        p.style = Paint.Style.FILL
        text(c, b.label, r.centerX(), r.centerY() + dp(6f), dp(18f),
            if (b.enabled) 0xFFFFFFFF.toInt() else 0xFFAAAAAA.toInt(), Paint.Align.CENTER)
    }

    fun statBar(c: Canvas, label: String, value: Float, x: Float, y: Float, w: Float, color: Int) {
        text(c, label, x, y, dp(13f), 0xFFDDE3F0.toInt(), shadow = false)
        val bx = x + dp(86f)
        val bw = w - dp(86f)
        p.style = Paint.Style.FILL
        p.color = 0x33FFFFFF
        r.set(bx, y - dp(11f), bx + bw, y + dp(1f))
        c.drawRoundRect(r, dp(6f), dp(6f), p)
        p.color = color
        r.set(bx, y - dp(11f), bx + bw * value.coerceIn(0.04f, 1f), y + dp(1f))
        c.drawRoundRect(r, dp(6f), dp(6f), p)
    }

    fun coinIcon(c: Canvas, cx: Float, cy: Float, rad: Float) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = 0xFFFFB300.toInt()
        c.drawCircle(cx, cy, rad, p)
        p.color = 0xFFFFE082.toInt()
        c.drawCircle(cx, cy, rad * 0.72f, p)
        p.color = 0xFFFFB300.toInt()
        c.drawCircle(cx, cy, rad * 0.35f, p)
    }

    fun title(c: Canvas, s: String, cx: Float, y: Float, size: Float) {
        text(c, s, cx, y, size, 0xFFFFFFFF.toInt(), Paint.Align.CENTER, heavyFont = true)
    }
}
