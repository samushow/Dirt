package com.dirtrush.game

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.cos
import kotlin.math.sin

/**
 * Disegna moto e quad con Canvas. Tutto in unita' "metri": il chiamante applica
 * translate/scale/rotate. Origine = baricentro, y verso l'alto (qui y e' gia' invertita dal chiamante).
 */
class VehicleRenderer {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private val tire = 0xFF16161A.toInt()
    private val rimColor = 0xFFC9CED6.toInt()
    private val metal = 0xFF8E959E.toInt()
    private val skin = 0xFFF2C29B.toInt()

    /** Disegna il veicolo completo con pilota. rearComp/frontComp: compressione sospensioni (m). */
    fun draw(c: Canvas, v: Vehicle, rearSpin: Float, frontSpin: Float,
             rearComp: Float, frontComp: Float, crashed: Boolean, riderTilt: Float) {
        val half = v.wheelbase / 2f
        val r = v.wheelRadius
        val drop = Bike.AXLE_DROP

        // Ombra morbida sotto
        p.style = Paint.Style.FILL
        p.color = 0x22000000

        if (v.type == VehicleType.MOTO) drawMoto(c, v, half, r, drop, rearSpin, frontSpin, rearComp, frontComp, crashed, riderTilt)
        else drawQuad(c, v, half, r, drop, rearSpin, frontSpin, rearComp, frontComp, crashed, riderTilt)
    }

    // ---------------- ruote ----------------
    private fun wheel(c: Canvas, cx: Float, cy: Float, r: Float, spin: Float, knobby: Boolean, wide: Float) {
        p.style = Paint.Style.FILL
        p.color = tire
        c.drawCircle(cx, cy, r, p)
        if (knobby) {
            // tasselli del copertone
            p.color = 0xFF2A2A30.toInt()
            for (i in 0 until 14) {
                val a = spin + i * (Math.PI.toFloat() * 2f / 14f)
                val bx = cx + cos(a) * (r - 0.015f)
                val by = cy + sin(a) * (r - 0.015f)
                c.drawCircle(bx, by, 0.028f * wide, p)
            }
        }
        p.color = rimColor
        c.drawCircle(cx, cy, r * 0.62f, p)
        p.color = tire
        c.drawCircle(cx, cy, r * 0.5f, p)
        // raggi
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.012f
        p.color = metal
        for (i in 0 until 8) {
            val a = spin + i * (Math.PI.toFloat() / 4f)
            c.drawLine(cx, cy, cx + cos(a) * r * 0.6f, cy + sin(a) * r * 0.6f, p)
        }
        p.style = Paint.Style.FILL
        p.color = metal
        c.drawCircle(cx, cy, r * 0.12f, p)
    }

    // ---------------- MOTO ----------------
    private fun drawMoto(c: Canvas, v: Vehicle, half: Float, r: Float, drop: Float,
                         rs: Float, fs: Float, rc: Float, fc: Float, crashed: Boolean, tilt: Float) {
        // In coordinate "schermo" (y positivo verso il basso) il chiamante ha gia' girato l'asse.
        val rearX = -half; val frontX = half
        val axleY = drop            // le ruote stanno sotto il baricentro
        val rcy = axleY - rc * 1.0f
        val fcy = axleY - fc * 1.0f

        // forcella anteriore (sospensione che si comprime)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 0.075f
        p.color = metal
        c.drawLine(frontX - 0.18f, -0.30f, frontX, fcy, p)
        p.strokeWidth = 0.05f
        p.color = v.accentColor
        c.drawLine(frontX - 0.18f, -0.30f, frontX - 0.09f + 0.0f, fcy - 0.28f, p)
        // forcellone posteriore + ammortizzatore
        p.strokeWidth = 0.07f
        p.color = metal
        c.drawLine(-0.12f, axleY - 0.12f, rearX, rcy, p)
        p.strokeWidth = 0.05f
        p.color = v.accentColor
        c.drawLine(-0.30f, -0.26f, -0.42f + rc * 0.2f, axleY - 0.20f, p)

        wheel(c, rearX, rcy, r, rs, true, 1f)
        wheel(c, frontX, fcy, r, fs, true, 1f)

        // parafango anteriore
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.05f
        p.color = v.bodyColor
        rect.set(frontX - r * 1.05f, fcy - r * 1.05f, frontX + r * 1.05f, fcy + r * 1.05f)
        c.drawArc(rect, 205f, 70f, false, p)

        // telaio, serbatoio e sella
        p.style = Paint.Style.FILL
        p.color = 0xFF2A2A30.toInt()
        c.drawRect(-0.25f, -0.05f, 0.30f, 0.30f, p)                  // motore
        p.color = metal
        c.drawCircle(0.04f, 0.14f, 0.09f, p)

        path.reset()                                                  // serbatoio + carena
        path.moveTo(-0.05f, -0.34f)
        path.cubicTo(0.12f, -0.56f, 0.38f, -0.48f, 0.46f, -0.30f)
        path.lineTo(0.40f, -0.05f)
        path.lineTo(-0.05f, -0.05f)
        path.close()
        p.color = v.bodyColor
        c.drawPath(path, p)

        path.reset()                                                  // sella e codone
        path.moveTo(-0.62f, -0.30f)
        path.lineTo(-0.05f, -0.40f)
        path.lineTo(-0.05f, -0.22f)
        path.lineTo(-0.55f, -0.10f)
        path.close()
        p.color = v.accentColor
        c.drawPath(path, p)

        // manubrio e faro/numero
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.045f
        p.color = 0xFF1B1B1F.toInt()
        c.drawLine(frontX - 0.30f, -0.52f, frontX - 0.20f, -0.62f, p)
        p.style = Paint.Style.FILL
        p.color = 0xFFFFFFFF.toInt()
        rect.set(frontX - 0.30f, -0.50f, frontX - 0.12f, -0.34f)
        c.drawRoundRect(rect, 0.04f, 0.04f, p)

        drawRider(c, -0.05f, -0.40f, frontX - 0.22f, -0.60f, 0.20f, tilt, crashed, v)
    }

    // ---------------- QUAD ----------------
    private fun drawQuad(c: Canvas, v: Vehicle, half: Float, r: Float, drop: Float,
                         rs: Float, fs: Float, rc: Float, fc: Float, crashed: Boolean, tilt: Float) {
        val rearX = -half; val frontX = half
        val axleY = drop
        val rcy = axleY - rc * 1.0f
        val fcy = axleY - fc * 1.0f

        // ruote lontane (leggermente piu' scure, effetto profondita')
        p.style = Paint.Style.FILL
        p.color = 0x66000000
        c.drawCircle(rearX + 0.06f, rcy - 0.05f, r, p)
        c.drawCircle(frontX + 0.06f, fcy - 0.05f, r, p)

        // bracci sospensione
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 0.07f
        p.color = metal
        c.drawLine(-0.15f, 0.12f, rearX, rcy, p)
        c.drawLine(frontX - 0.2f, 0.05f, frontX, fcy, p)

        wheel(c, rearX, rcy, r, rs, true, 1.6f)
        wheel(c, frontX, fcy, r, fs, true, 1.6f)

        // telaio
        p.style = Paint.Style.FILL
        p.color = 0xFF2A2A30.toInt()
        c.drawRect(-0.35f, -0.02f, 0.35f, 0.26f, p)

        // carrozzeria
        path.reset()
        path.moveTo(-0.65f, -0.22f)
        path.lineTo(-0.15f, -0.34f)
        path.cubicTo(0.10f, -0.52f, 0.45f, -0.50f, frontX + 0.15f, -0.22f)
        path.lineTo(frontX + 0.12f, 0.02f)
        path.lineTo(-0.60f, 0.02f)
        path.close()
        p.color = v.bodyColor
        c.drawPath(path, p)

        // sella + fascia colore
        p.color = v.accentColor
        rect.set(-0.55f, -0.36f, -0.05f, -0.22f)
        c.drawRoundRect(rect, 0.05f, 0.05f, p)
        p.alpha = 200
        c.drawRect(-0.55f, -0.10f, 0.50f, -0.04f, p)
        p.alpha = 255

        // paraurti, manubrio, faro
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.05f
        p.color = 0xFF1B1B1F.toInt()
        c.drawLine(frontX - 0.18f, -0.52f, frontX - 0.08f, -0.64f, p)
        c.drawLine(frontX + 0.15f, -0.05f, frontX + 0.30f, -0.15f, p)
        p.style = Paint.Style.FILL
        p.color = 0xFFFFF59D.toInt()
        c.drawCircle(frontX + 0.12f, -0.18f, 0.07f, p)

        drawRider(c, -0.28f, -0.34f, frontX - 0.10f, -0.62f, 0.14f, tilt, crashed, v)
    }

    // ---------------- PILOTA ----------------
    private fun drawRider(c: Canvas, hipX: Float, hipY: Float, handX: Float, handY: Float,
                          footY: Float, tilt: Float, crashed: Boolean, v: Vehicle) {
        val lean = if (crashed) -0.35f else tilt * 0.12f
        val shX = hipX + 0.10f + lean
        val shY = hipY - 0.55f
        // gambe
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 0.11f
        p.color = 0xFF263238.toInt()
        c.drawLine(hipX, hipY, hipX + 0.32f, footY - 0.05f, p)
        // busto
        p.strokeWidth = 0.17f
        p.color = v.bodyColor
        c.drawLine(hipX, hipY, shX, shY, p)
        // braccio
        p.strokeWidth = 0.075f
        p.color = v.accentColor
        c.drawLine(shX, shY, handX, handY, p)
        // casco
        p.style = Paint.Style.FILL
        p.color = skin
        c.drawCircle(shX + 0.03f, shY - 0.13f, 0.09f, p)
        p.color = v.accentColor
        rect.set(shX - 0.11f, shY - 0.30f, shX + 0.17f, shY - 0.10f)
        c.drawArc(rect, 160f, 220f, true, p)
        p.color = 0xCC1B1B1F.toInt()
        rect.set(shX + 0.06f, shY - 0.20f, shX + 0.18f, shY - 0.12f)
        c.drawRoundRect(rect, 0.03f, 0.03f, p)             // visiera
    }
}
