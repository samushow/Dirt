package com.dirtrush.game

enum class VehicleType { MOTO, QUAD }

enum class Style { MOTOCROSS, ENDURO, TRIAL, SPORT, QUAD_SPORT, QUAD_UTILITY }

/**
 * Modelli originali (nomi di fantasia) di moto e quad.
 * power: accelerazione in m/s^2, grip: aderenza 0..1+, stability: stabilita' in aria,
 * suspension: morbidezza sospensioni (piu' alto = piu' morbide), price: monete per sbloccarlo.
 */
data class Vehicle(
    val id: String,
    val name: String,
    val type: VehicleType,
    val style: Style,
    val bodyColor: Int,
    val accentColor: Int,
    val mass: Float,
    val wheelbase: Float,
    val wheelRadius: Float,
    val power: Float,
    val grip: Float,
    val stability: Float,
    val suspension: Float,
    val price: Int
)

object Catalog {
    private fun c(hex: Long) = (0xFF000000L or hex).toInt()

    val vehicles: List<Vehicle> = listOf(
        // ---- MOTO ----
        Vehicle("mx250", "Falco MX 250", VehicleType.MOTO, Style.MOTOCROSS,
            c(0xFF6A00), c(0x1B1B1F), 105f, 1.45f, 0.34f, 7.5f, 1.0f, 1.0f, 1.0f, 0),
        Vehicle("mx450", "Falco MX 450", VehicleType.MOTO, Style.MOTOCROSS,
            c(0xE53935), c(0xFFFFFF), 110f, 1.47f, 0.34f, 8.5f, 1.0f, 0.95f, 1.0f, 600),
        Vehicle("enduro", "Tundra Enduro 300", VehicleType.MOTO, Style.ENDURO,
            c(0x2E7D32), c(0xFFD600), 115f, 1.48f, 0.35f, 7.0f, 1.25f, 1.1f, 1.2f, 900),
        Vehicle("trial", "Gnomo Trial 125", VehicleType.MOTO, Style.TRIAL,
            c(0x1E88E5), c(0xFFFFFF), 80f, 1.25f, 0.31f, 5.5f, 1.5f, 1.5f, 1.3f, 1200),
        Vehicle("supermoto", "Vortex Supermoto", VehicleType.MOTO, Style.SPORT,
            c(0x8E24AA), c(0x00E5FF), 120f, 1.40f, 0.30f, 9.0f, 0.85f, 0.85f, 0.8f, 1800),
        Vehicle("thunder", "Thunder X-Pro", VehicleType.MOTO, Style.MOTOCROSS,
            c(0x00BFA5), c(0x212121), 108f, 1.46f, 0.34f, 10.0f, 1.05f, 1.1f, 1.1f, 3000),
        // ---- QUAD ----
        Vehicle("quad200", "Scarab Quad 200", VehicleType.QUAD, Style.QUAD_UTILITY,
            c(0x6D4C41), c(0xFFCA28), 190f, 1.30f, 0.38f, 6.0f, 1.3f, 0.9f, 1.4f, 400),
        Vehicle("quad450", "Scarab Sport 450", VehicleType.QUAD, Style.QUAD_SPORT,
            c(0xD81B60), c(0xFFFFFF), 175f, 1.28f, 0.37f, 8.5f, 1.2f, 0.95f, 1.2f, 1000),
        Vehicle("quadrace", "Rhino Race 700", VehicleType.QUAD, Style.QUAD_SPORT,
            c(0xFDD835), c(0x212121), 180f, 1.30f, 0.38f, 9.5f, 1.15f, 1.0f, 1.1f, 2200),
        Vehicle("quadmonster", "Yeti Monster 4x4", VehicleType.QUAD, Style.QUAD_UTILITY,
            c(0x3949AB), c(0xFF6A00), 230f, 1.40f, 0.46f, 9.5f, 1.6f, 0.8f, 1.5f, 3500)
    )

    fun byId(id: String): Vehicle = vehicles.firstOrNull { it.id == id } ?: vehicles[0]
}
